# Bread Clicker
Play at <a href="https://phyllip3.github.io/breadclicker/">https://phyllip3.github.io/breadclicker/</a>

Bread Clicker is an incremental game where players operate a bakery.

The visual elements of this game are inspired by <a href="http://adarkroom.doublespeakgames.com">A Dark Room</a>.

This game is a work in progress, and was created to teach myself basic web development.
