# RurimoOnlineServer
흑바온 게임 서버

## Port
포트는 `52000`을 사용하고 있음.

## Database 구축
mysql을 이용하여 database 폴더의 sql 파일 실행.

## 포트포워딩
52000 포트 포트포워딩을 통해서 외부 아이피 접속 허용.
