#include "../pch.h"
#include "CResource.h"

CResource::CResource()
{
}

CResource::~CResource()
{
}