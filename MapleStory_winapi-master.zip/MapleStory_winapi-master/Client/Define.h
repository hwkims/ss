#pragma once

// Singletion Macro
#define SINGLETON(type)	public:\
							static type* GetInst()\
							{\
								static type Manager;\
								return &Manager;\
							}\
						private:\
							type();\
							~type();

#define SAFE_RELEASE(p)		if(p) { p->Release(); p = NULL; }

#define fDeltaTime CTimeManager::GetInst()->GetfDeltaTime()
#define DeltaTime CTimeManager::GetInst()->GetDeltaTime()

// �Ͻ��� ��������� ȣ���� ��� �θ� ��������� ȣ��ȴ�.
#define CLONE(type) type* Clone() { return new type(*this); }

#define KEY_CHECK(key, state) CKeyManager::GetInst()->GetKeyState(key) == state
#define KEY_HOLD(key) KEY_CHECK(key, KEY_STATE::HOLD)
#define KEY_TAP(key) KEY_CHECK(key, KEY_STATE::TAP)
#define KEY_AWAY(key) KEY_CHECK(key, KEY_STATE::AWAY)
#define KEY_NONE(key) KEY_CHECK(key, KEY_STATE::NONE)
#define MOUSE_POS CKeyManager::GetInst()->GetMousePos()

enum class SCENE_TYPE
{
	START,
	STAGE_01,
	STAGE_02,

	END,
};

enum class BRUSH_TYPE
{
	HOLLOW,
	BLACK,
	END,
};

enum class PEN_TYPE
{
	RED,
	GREEN,
	BLUE,
	YELLOW,
	END,
};

enum class OBJECT_TYPE
{
	DEFAULT,
	ITEM,
	MESO,
	PORTAL,
	BACKGROUND,
	PIXEL_BACKGROUND,
	PLAYER,
	MONSTER,
	RECTANGLE,
	PIXEL,

	UI = 31,
	END = 32,
};

enum class EVENT_TYPE
{
	CREATE_OBJECT,
	DELETE_OBJECT,
	SCENE_CHANGE,
	CHANGE_AI_STATE,

	END,
};

enum class MON_STATE
{
	IDLE,		// ��� ����
	PATROL,		// ���� ����
	TRACE,		// ���� ����
	ATTACK,		// ����
	RUN,
	DEAD,
};

enum class PLAYER_STATE
{
	IDLE,
	WALK,
	ATTACK,
	JUMP,
	ROPE,
	DEAD,
};

enum COLLISION_STATE
{
	CS_ENTER,
	CS_STAY,
	CS_EXIT
};

enum COLLIDER_TYPE
{
	CT_RECTANGLE,
	CT_PIXEL
};

enum ITEM_TAG
{
	IT_NONE,
	IT_RED_POTION,
	IT_MESO,
	IT_SIZE
};