import React from 'react'

function LoginPage() {
  return (
    <div>LoginPage</div>
  )
}

export default LoginPage;