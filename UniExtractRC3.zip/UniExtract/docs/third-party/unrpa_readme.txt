Unrpa is a script to extract files from archives created for the Ren'Py Visual Novel Engine (http://www.renpy.org/).

Options:
  --version             show program's version number and exit
  -h, --help            show this help message and exit
  -v, --verbose         explain what is being done [default]
  -s, --silent          make no output
  -l, --list            only list contents, do not extract
  -p PATH, --path=PATH  will extract to the given path
  -m, --mkdir           will make any non-existant directories in extraction
                        path
  -f VERSION, --force=VERSION
                        forces an archive version. May result in failure.
                        
Usage: unrpa [options] pathname

