import example from "./ex01";
// import example from "./ex02";
// import example from "./ex03";
// import example from "./ex04";
// import example from "./ex05";
// import example from "./ex06";
// import example from "./ex07";

example();
