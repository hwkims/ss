import example from './ex01';

example();
