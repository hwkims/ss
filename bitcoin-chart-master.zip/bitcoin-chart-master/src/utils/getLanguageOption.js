const getLanguageOption = () => {
  return {
    candle: {
      tooltip: {
        labels: ['T: ', 'O: ', 'C: ', 'H: ', 'L: ', 'V: ']
      }
    }
  }
}

export default getLanguageOption;