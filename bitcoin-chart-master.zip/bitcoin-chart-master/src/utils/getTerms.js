const getTerms = () => {
  return {
    candle: {
      tooltip: {
        labels: ['T: ', 'O: ', 'C: ', 'H: ', 'L: ', 'V: ']
      }
    }
  }
}

export default getTerms;