import './app.scss';
import CoinChart from './chart/CoinChart';

function App() {
  return (
    <div className="app">
      <CoinChart/>
    </div>
  );
}

export default App;
