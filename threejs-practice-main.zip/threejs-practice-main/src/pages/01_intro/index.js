import * as THREE from 'three';

console.log('lec01 > main.js');
// ----- 주제: 기본 장면
