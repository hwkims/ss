import '../styles/main.css';
import '../styles/global.scss';
// import example from "./02";
// import example from "./03";
// import example from "./04";
// import example from "./05_geometry";
import example from "./06_cameraControl";

// ! console.log("웹펙 > entry > main 으로 설정된 js 파일 경우, HOT RELOAD 적용");
example();
