# Hello World Test Application

This is the [**React Native**](https://reactnative.dev) HelloWorld test app. It is for internal use and shouldn't be dependend on.
