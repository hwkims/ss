/**
----------------------------------------------------------------------------------
	Skyferry Between Victoria Island, Ereve and Orbis.

	1100005 Kiriru (On boat between Ereve and Victoria Island)

        Credits to: MapleSanta 
----------------------------------------------------------------------------------
**/

function start() {
	cm.sendOk("The weather is so nice. At this rate, we should arrive in no time....");
	cm.dispose();
}