function start() {
	cm.getPlayer().getStorage().sendStorage(cm.getClient(), 1100000);
	cm.dispose();
}