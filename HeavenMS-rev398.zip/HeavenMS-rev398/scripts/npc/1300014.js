function start() {
    cm.dispose();
}