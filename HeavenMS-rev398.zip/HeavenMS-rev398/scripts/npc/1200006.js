/**
----------------------------------------------------------------------------------
	Whale Between Lith harbor and Rien.

	1200006 Puro

        Credits to: MapleSanta 
----------------------------------------------------------------------------------
**/

function start() {
    cm.sendOk("The current is serene, wich means we may arive in lith harbor earlier than expected.");
    cm.dispose();
}