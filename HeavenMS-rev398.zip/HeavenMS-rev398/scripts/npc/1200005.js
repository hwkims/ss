/**
----------------------------------------------------------------------------------
	Whale Between Lith harbor and Rien.

	1200005 Puro

        Credits to: MapleSanta 
----------------------------------------------------------------------------------
**/

function start() {
	cm.sendOk("Ahhhh, this is so boring... The whale is controlling the ship so i'm left with nothing to do but look up and stare at the clouds.");
	cm.dispose()
}