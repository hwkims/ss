function start() {
    cm.sendNext("It looks like there's nothing suspecious in the area.");
    cm.dispose();
}