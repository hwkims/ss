/**
----------------------------------------------------------------------------------
	Skyferry Between Victoria Island, Ereve and Orbis.

	1100006 Kiru (On boat between Ereve and Orbis)

        Credits to: MapleSanta 
----------------------------------------------------------------------------------
**/

function start() {
    cm.sendOk("Ah, such lovely winds. This should be a perfect voyage as long as no stupid customer falls off for attempting some weird skill. Of course, I'm talking about you. Please refrain from using your skills.");
    cm.dispose();
}