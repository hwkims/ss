function start(ms) { 
	ms.updateAreaInfo(23007, "exp1=1;exp2=1;exp3=1;exp4=1");//force
	ms.showInfo("Effect/OnUserEff.img/guideEffect/resistanceTutorial/userTalk");
}