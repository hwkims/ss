function start(ms) {
	ms.setDirectionStatus(true);
    ms.showIntro("Effect/Direction4.img/cannonshooter/Scene00");
    ms.showIntro("Effect/Direction4.img/cannonshooter/out00");
}