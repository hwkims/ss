function start(ms) { 
	ms.setStandAloneMode(true);
}