function start(ms) {
	ms.lockUI();
	ms.showIntro("Effect/Direction4.img/getDragonEgg/Scene" + ms.getPlayer().getGender());
}