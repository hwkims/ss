import * as hello from './hello.js';

hello.hello1();
hello.hello2();
